namespace PoSophornCafe.Services;

/// <summary>Current time in the shop's time zone (so a server in another country still reports the right "today").</summary>
public class ShopClock
{
    private readonly TimeZoneInfo _tz;

    public ShopClock(IConfiguration config)
    {
        try { _tz = TimeZoneInfo.FindSystemTimeZoneById(config["ShopTimeZone"] ?? "Asia/Phnom_Penh"); }
        catch { _tz = TimeZoneInfo.Local; }
    }

    public DateTime Now => TimeZoneInfo.ConvertTime(DateTime.UtcNow, _tz);
    public DateTime Today => Now.Date;
}
