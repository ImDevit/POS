// Shared JavaScript. Data lives in SQL Server; this file only handles the screen and printing.
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const money = (n) => '$' + Number(n || 0).toFixed(2);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const page = document.body.dataset.page;

  function toast(message) {
    const node = $('#toast'); if (!node || !message) return;
    node.textContent = message; node.classList.add('show');
    clearTimeout(toast.t); toast.t = setTimeout(() => node.classList.remove('show'), 3000);
  }
  const token = () => $('input[name="__RequestVerificationToken"]')?.value || '';

  // Messages sent from the server (TempData), e.g. "Product added."
  const flash = $('#toast')?.dataset.message; if (flash) toast(flash);
  $('#logoutButton')?.addEventListener('click', () => toast('Login is not set up yet. Add ASP.NET Identity to enable logout.'));
  // <form data-confirm="..."> asks before submitting (delete buttons)
  $$('form[data-confirm]').forEach(f => f.addEventListener('submit', e => { if (!confirm(f.dataset.confirm)) e.preventDefault(); }));
  // <select|input data-autosubmit> reloads the page with the new filter
  $$('[data-autosubmit]').forEach(el => el.addEventListener('change', () => el.form.submit()));

  // ---------------------------------------------------------------- receipts
  const SHOP = { name: 'Po Sophorn Cafe', addr: 'Street 210, Sangkat Takhmao, Takhmao City, Kandal Province', cashier: 'Po Sophorn Cafe' };
  const RECEIPT_CSS = `@page{margin:6mm}
body{font:12px Inter,'Noto Sans Khmer',Arial,sans-serif;color:#111;width:300px;margin:0 auto;padding:14px 0;background:#fff}
.logo{display:block;margin:0 auto 8px;width:80px;height:80px;object-fit:contain}
h1{font-size:17px;text-align:center;margin:6px 0}
.addr{text-align:center;font-weight:700;color:#666;font-size:12px;line-height:1.35;margin:10px 6px 18px}
.title{text-align:center;font-weight:700;font-size:13px;line-height:1.5}
.row{display:flex;justify-content:space-between;gap:8px;margin:7px 0}.row.b{font-weight:700}.row span:last-child{text-align:right}
hr{border:0;border-top:1px solid #777;margin:8px 0}hr.thick{border-top:2px solid #111}
table{width:100%;border-collapse:collapse}th{font-weight:400;text-align:right;vertical-align:top;padding:2px 0 2px 8px}td{padding:5px 0 5px 8px;text-align:right}
th:first-child,td:first-child{text-align:left;padding-left:0}
.tot{display:flex;justify-content:space-between}.tot .l{line-height:1.8}.tot .r{text-align:right;line-height:1.8;min-width:150px;display:grid;grid-template-columns:1fr auto;column-gap:14px}
.foot{text-align:center;margin-top:14px;font-size:11px;color:#555}`;
  const rcRow = (kh, en, val, bold) => `<div class="row ${bold ? 'b' : ''}"><span>${kh}${en}</span><span>${val}</span></div>`;

  function receiptHTML({ title, headRows, lines, totalQty, total }) {
    return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(title)}</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Noto+Sans+Khmer:wght@400;600;700&display=swap" rel="stylesheet"><style>${RECEIPT_CSS}</style></head><body>
<img class="logo" src="${location.origin}/img/logo.png" alt="">
<h1>${SHOP.name}</h1><div class="addr">${SHOP.addr}</div>
<div class="title">វិក្កយបត្រ<br>RECEIPT</div><br>
${headRows}
<table><thead><tr><th>បរិយាយទំនិញ<br>Description</th><th>ចំនួន<br>Qty</th><th>តម្លៃ<br>Price</th><th>ប.តម្លៃ<br>Disc</th><th>សរុប<br>Amt</th></tr></thead>
<tbody>${lines.map(l => `<tr><td>${esc(l.name.toUpperCase())}</td><td>${l.qty}</td><td>${money(l.price)}</td><td>0%</td><td>${money(l.qty * l.price)}</td></tr>`).join('')}</tbody></table>
<hr class="thick">
<div class="tot"><div class="l">ចំនួនសរុប<br>សរុប<br>បញ្ចុះតម្លៃ</div><div class="r"><span>Total QTY:</span><span>${totalQty}</span><span>Sub Total ($):</span><span>${money(total)}</span><span>Discount(0.00%):</span><span>0.00$</span></div></div>
<hr class="thick">
<div class="tot"><div class="l">ប្រាក់ទទួល($)</div><div class="r"><span>Receive / CASH USD:</span><span>${money(total)}</span></div></div>
<hr class="thick"><div class="foot">Thank you!</div></body></html>`;
  }

  // Prints through a hidden frame, so browsers never block it like a pop-up window.
  function printHtml(html) {
    const frame = document.createElement('iframe');
    frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
    document.body.appendChild(frame);
    frame.srcdoc = html;
    frame.onload = () => setTimeout(() => {
      frame.contentWindow.focus(); frame.contentWindow.print();
      setTimeout(() => frame.remove(), 60000);
    }, 700);
  }

  // Invoice of one saved order (also used to print it again). Never creates a new order.
  function printReceipt(o) {
    const qty = o.items.reduce((s, i) => s + i.qty, 0);
    const head = rcRow('', 'Order Type', esc(o.orderType || 'Take Away'), true) + rcRow('លេខរង់ចាំ', '', esc(o.queue || ''), true) + '<hr>'
      + rcRow('លេខវិក្កយបត្រ/', 'Invoice', esc(o.number)) + rcRow('បេឡាករ/', 'Cashier', SHOP.cashier)
      + rcRow('អតិថិជន/', 'Customer', 'Walk In') + rcRow('កាលបរិច្ឆេទ/', 'Date', esc(o.dateText)) + '<hr>';
    printHtml(receiptHTML({ title: 'Receipt ' + o.number, headRows: head, lines: o.items, totalQty: qty, total: o.total }));
  }

  async function reprint(number) {
    try {
      const res = await fetch('/api/orders/' + encodeURIComponent(number));
      if (!res.ok) throw 0;
      printReceipt(await res.json());
    } catch { toast('Could not load that invoice.'); }
  }
  const bindReprint = (root = document) => $$('[data-reprint]', root).forEach(b => {
    if (b.dataset.bound) return; b.dataset.bound = '1';
    b.addEventListener('click', () => reprint(b.dataset.reprint));
  });
  bindReprint();

  // ---------------------------------------------------------------- Orders page
  if (page === 'orders') {
    const cart = new Map(); // productId -> {id,name,price,qty}
    let lastNumber = null;
    const cards = $$('.drink-card');
    const cardOf = (id) => cards.find(c => Number(c.dataset.id) === id);
    const stockOf = (id) => Number(cardOf(id)?.dataset.qty || 0);

    function renderCart() {
      const items = [...cart.values()];
      $('#cartRows').innerHTML = items.length ? items.map(i => `<div class="cart-item"><div><div class="cart-item-name">${esc(i.name)}</div><div class="cart-item-sub">${money(i.price)} each</div><div class="qty-controls"><button type="button" data-minus="${i.id}">−</button><b>${i.qty}</b><button type="button" data-plus="${i.id}">+</button><button type="button" class="remove-item" data-remove="${i.id}">Remove</button></div></div><b>${money(i.qty * i.price)}</b></div>`).join('')
        : '<div class="cart-empty">Your order is empty.<br>Choose a drink to begin.</div>';
      $('#cartTotal').textContent = money(items.reduce((s, i) => s + i.price * i.qty, 0));
      $$('[data-minus]').forEach(b => b.onclick = () => change(Number(b.dataset.minus), -1));
      $$('[data-plus]').forEach(b => b.onclick = () => change(Number(b.dataset.plus), 1));
      $$('[data-remove]').forEach(b => b.onclick = () => { cart.delete(Number(b.dataset.remove)); renderCart(); });
    }
    function change(id, delta) {
      const line = cart.get(id); if (!line) return;
      if (delta > 0 && line.qty >= stockOf(id)) { toast('Not enough stock available.'); return; }
      line.qty += delta; if (line.qty <= 0) cart.delete(id); renderCart();
    }
    cards.forEach(c => c.addEventListener('click', () => {
      const id = Number(c.dataset.id), line = cart.get(id);
      if ((line?.qty || 0) >= stockOf(id)) { toast('Not enough stock available.'); return; }
      if (line) line.qty++; else cart.set(id, { id, name: c.dataset.name, price: Number(c.dataset.price), qty: 1 });
      renderCart();
    }));
    $('#menuSearch').addEventListener('input', e => {
      const t = e.target.value.toLowerCase().trim();
      cards.forEach(c => c.classList.toggle('hidden', !c.dataset.search.includes(t)));
    });
    $('#clearCart').addEventListener('click', () => { cart.clear(); renderCart(); });

    function applyStock(list) {
      list.forEach(s => {
        const c = cardOf(s.id); if (!c) return;
        c.dataset.qty = s.qty; c.disabled = s.qty < 1;
        $('.avail', c).textContent = s.qty > 0 ? `Available: ${s.qty}` : 'Out of stock';
      });
    }
    function addRecentRow(o) {
      $('#noOrders')?.remove();
      const tr = document.createElement('tr');
      tr.innerHTML = `<td class="code-text">${esc(o.number)}</td><td>${esc(o.dateText)}</td><td>${o.items.map(i => `${esc(i.name)} × ${i.qty}`).join(', ')}</td><td><b>${money(o.total)}</b></td><td><button type="button" class="btn btn-outline btn-small" data-reprint="${esc(o.number)}">⎙ Print again</button></td>`;
      $('#recentOrderRows').prepend(tr); bindReprint(tr);
    }

    const payBtn = $('#paymentButton');
    payBtn.addEventListener('click', async () => {
      if (!cart.size) { toast('Please add at least one product first.'); return; }
      payBtn.disabled = true;
      try {
        const res = await fetch('?handler=Pay', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'RequestVerificationToken': token() },
          body: JSON.stringify({ orderType: $('#orderType').value, items: [...cart.values()].map(i => ({ productId: i.id, qty: i.qty })) })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) { toast(data.error || 'Payment failed. Please try again.'); return; }
        lastNumber = data.order.number;
        cart.clear(); renderCart(); applyStock(data.stock); addRecentRow(data.order);
        $('#currentOrderNo').textContent = lastNumber; $('#printLastButton').classList.remove('hidden');
        toast('Order saved. Printing invoice…');
        printReceipt(data.order);
      } catch { toast('Cannot reach the server.'); }
      finally { payBtn.disabled = false; }
    });
    $('#printLastButton').addEventListener('click', () => lastNumber && reprint(lastNumber));
    renderCart();
  }

  // ---------------------------------------------------------------- Report page
  if (page === 'reports') {
    $('#printReport')?.addEventListener('click', () => {
      const d = JSON.parse($('#reportData').textContent);
      if (!d.orderCount) { toast('No orders in this period to print.'); return; }
      const head = rcRow('', 'Report Type', esc(d.typeLabel), true) + rcRow('ចំនួនការបញ្ជាទិញ/', 'Orders', d.orderCount, true) + '<hr>'
        + rcRow('កាលបរិច្ឆេទ/', 'Date', esc(d.periodLabel)) + rcRow('បេឡាករ/', 'Cashier', SHOP.cashier)
        + rcRow('ព្រីនពេល/', 'Printed', esc(new Date().toLocaleString())) + '<hr>';
      printHtml(receiptHTML({ title: 'Report', headRows: head, lines: d.lines, totalQty: d.totalQty, total: d.total }));
    });
  }
})();
