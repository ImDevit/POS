using System.Globalization;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Data;
using PoSophornCafe.Models;
using PoSophornCafe.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddSingleton<ShopClock>();
// JavaScript (fetch) sends the anti-forgery token in this header.
builder.Services.AddAntiforgery(options => options.HeaderName = "RequestVerificationToken");

var app = builder.Build();

// Create the database + tables on first run, then add the sample drinks.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();

    // EnsureCreated() never changes an existing database. If the DB was created before a column
    // was added to Product, add the missing columns here (safe to run every start).
    db.Database.ExecuteSqlRaw(@"
IF COL_LENGTH('Products', 'ImagePath') IS NULL
    ALTER TABLE Products ADD ImagePath nvarchar(500) NULL;
IF COL_LENGTH('Products', 'Emoji') IS NULL
    ALTER TABLE Products ADD Emoji nvarchar(10) NULL;");

    SeedData.Initialize(db);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

// One culture everywhere so "1.50" is always written with a dot (needed by <input type="number">).
var culture = new CultureInfo("en-US");
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(culture),
    SupportedCultures = new[] { culture },
    SupportedUICultures = new[] { culture }
});

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Used to print an invoice again (Orders + Report pages). Read-only: it never creates an order.
app.MapGet("/api/orders/{number}", async (string number, AppDbContext db) =>
{
    var order = await db.Orders.Include(o => o.Items).AsNoTracking()
        .FirstOrDefaultAsync(o => o.Number == number);
    return order is null ? Results.NotFound(new { error = "Order not found." }) : Results.Ok(OrderDto.From(order));
});

app.MapRazorPages();
app.Run();