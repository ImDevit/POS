namespace PoSophornCafe.Models;

// The shape sent to JavaScript to print an invoice.
public record OrderItemDto(string Name, decimal Price, int Qty);

public record OrderDto(string Number, int Queue, string OrderType, string DateText, decimal Total, List<OrderItemDto> Items)
{
    public static OrderDto From(Order o) => new(
        o.Number, o.Queue, o.OrderType,
        o.OrderDate.ToString("dd/MM/yyyy hh:mm tt"),
        o.Total,
        o.Items.Select(i => new OrderItemDto(i.Name, i.Price, i.Qty)).ToList());
}
