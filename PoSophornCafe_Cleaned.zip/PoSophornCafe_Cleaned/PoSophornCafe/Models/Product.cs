using System.ComponentModel.DataAnnotations;

namespace PoSophornCafe.Models;

public class Product
{
    public int Id { get; set; }

    [Required, StringLength(30)]
    [Display(Name = "Product Code")]
    public string Code { get; set; } = "";

    [Required, StringLength(100)]
    [Display(Name = "Product Name")]
    public string Name { get; set; } = "";

    [Range(0, 100000)]
    [Display(Name = "Quantity in stock")]
    public int Qty { get; set; }

    [Range(0.01, 100000)]
    [Display(Name = "Price (USD)")]
    public decimal Price { get; set; }

    [StringLength(10)]
    public string? Emoji { get; set; } = "☕";

    // Product image URL/path
    [StringLength(500)]
    public string? ImagePath { get; set; }

    [Timestamp]
    public byte[]? RowVersion { get; set; }
}   