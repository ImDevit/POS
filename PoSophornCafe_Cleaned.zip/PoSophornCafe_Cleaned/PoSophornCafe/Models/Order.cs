namespace PoSophornCafe.Models;

public class Order
{
    public int Id { get; set; }
    public string Number { get; set; } = "";      // invoice number, e.g. POS1-00012
    public int Queue { get; set; }                // waiting number, restarts every day
    public string OrderType { get; set; } = "Take Away";
    public DateTime OrderDate { get; set; }       // shop local time
    public decimal Total { get; set; }
    public List<OrderItem> Items { get; set; } = new();
}

public class OrderItem
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order? Order { get; set; }
    public int? ProductId { get; set; }           // becomes NULL if the product is deleted later
    public Product? Product { get; set; }
    public string Name { get; set; } = "";        // name and price are copied so old invoices never change
    public decimal Price { get; set; }
    public int Qty { get; set; }
}
