using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Data;
using PoSophornCafe.Models;
using System.Text;

namespace PoSophornCafe.Pages.Products;

public class EditModel : PageModel
{
    private readonly AppDbContext _db;
    private readonly IWebHostEnvironment _environment;

    private const long MaxImageSize = 5 * 1024 * 1024;

    public EditModel(
        AppDbContext db,
        IWebHostEnvironment environment)
    {
        _db = db;
        _environment = environment;
    }

    [BindProperty]
    public Product Input { get; set; } = new();

    [BindProperty]
    public IFormFile? ImageFile { get; set; }

    public async Task<IActionResult> OnGetAsync(int? id)
    {
        if (id == null)
            return Page();

        var product = await _db.Products
            .AsNoTracking()
            .FirstOrDefaultAsync(p => p.Id == id);

        if (product == null)
            return NotFound();

        Input = product;

        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        Input.Code = (Input.Code ?? "").Trim();
        Input.Name = (Input.Name ?? "").Trim();

        ModelState.Remove("Input.RowVersion");

        Product? existing = null;

        if (Input.Id != 0)
        {
            existing = await _db.Products.FindAsync(Input.Id);

            if (existing == null)
                return NotFound();
        }

        // Validate duplicate product code
        if (await _db.Products.AnyAsync(p =>
            p.Code == Input.Code && p.Id != Input.Id))
        {
            ModelState.AddModelError(
                "Input.Code",
                "That product code already exists.");
        }

        // Validate uploaded image
        if (ImageFile != null && ImageFile.Length > 0)
        {
            var extension = Path.GetExtension(ImageFile.FileName)
                .ToLowerInvariant();

            var allowedExtensions = new[]
            {
                ".jpg", ".jpeg", ".png", ".webp"
            };

            if (ImageFile.Length > MaxImageSize)
            {
                ModelState.AddModelError(
                    "ImageFile",
                    "Image size must be less than 5MB.");
            }
            else if (!allowedExtensions.Contains(extension))
            {
                ModelState.AddModelError(
                    "ImageFile",
                    "Only JPG, PNG and WEBP images are allowed.");
            }
            else if (!await IsValidImageAsync(ImageFile, extension))
            {
                ModelState.AddModelError(
                    "ImageFile",
                    "Invalid image file.");
            }
        }

        if (!ModelState.IsValid)
        {
            Input.ImagePath = existing?.ImagePath;
            return Page();
        }

        string? oldImagePath = existing?.ImagePath;

        // Save uploaded image
        if (ImageFile != null && ImageFile.Length > 0)
        {
            var uploadFolder = Path.Combine(
                _environment.WebRootPath,
                "uploads",
                "products");

            Directory.CreateDirectory(uploadFolder);

            var extension = Path.GetExtension(ImageFile.FileName)
                .ToLowerInvariant();

            var fileName = $"{Guid.NewGuid():N}{extension}";

            var filePath = Path.Combine(uploadFolder, fileName);

            await using (var stream = new FileStream(
                filePath,
                FileMode.CreateNew))
            {
                await ImageFile.CopyToAsync(stream);
            }

            Input.ImagePath = $"/uploads/products/{fileName}";
        }
        else
        {
            Input.ImagePath = existing?.ImagePath;
        }

        if (existing == null)
        {
            Input.Emoji = null;

            _db.Products.Add(Input);

            TempData["Message"] = "Product added successfully.";
        }
        else
        {
            existing.Code = Input.Code;
            existing.Name = Input.Name;
            existing.Qty = Input.Qty;
            existing.Price = Input.Price;
            existing.ImagePath = Input.ImagePath;

            TempData["Message"] = "Product updated successfully.";
        }

        await _db.SaveChangesAsync();

        // Remove old image after successful update
        if (!string.IsNullOrEmpty(oldImagePath) &&
            oldImagePath != Input.ImagePath)
        {
            DeleteOldImage(oldImagePath);
        }

        return RedirectToPage("Index");
    }

    private static async Task<bool> IsValidImageAsync(
        IFormFile file,
        string extension)
    {
        byte[] header = new byte[12];

        await using var stream = file.OpenReadStream();

        int count = await stream.ReadAsync(header.AsMemory());

        return extension switch
        {
            ".jpg" or ".jpeg" =>
                count >= 3 &&
                header[0] == 0xFF &&
                header[1] == 0xD8 &&
                header[2] == 0xFF,

            ".png" =>
                count >= 8 &&
                header.Take(8).SequenceEqual(
                    new byte[] {
                        0x89, 0x50, 0x4E, 0x47,
                        0x0D, 0x0A, 0x1A, 0x0A
                    }),

            ".webp" =>
                count >= 12 &&
                Encoding.ASCII.GetString(header, 0, 4) == "RIFF" &&
                Encoding.ASCII.GetString(header, 8, 4) == "WEBP",

            _ => false
        };
    }

    private void DeleteOldImage(string imagePath)
    {
        var fileName = Path.GetFileName(imagePath);

        var folder = Path.GetFullPath(
            Path.Combine(_environment.WebRootPath, "uploads", "products"));

        var fullPath = Path.Combine(folder, fileName);

        if (System.IO.File.Exists(fullPath))
        {
            System.IO.File.Delete(fullPath);
        }
    }
}