using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Data;
using PoSophornCafe.Models;

namespace PoSophornCafe.Pages.Products;

public class IndexModel : PageModel
{
    private readonly AppDbContext _db;
    public IndexModel(AppDbContext db) => _db = db;

    [BindProperty(SupportsGet = true)] public string? Search { get; set; }
    public List<Product> Products { get; set; } = new();

    public async Task OnGetAsync()
    {
        var q = _db.Products.AsNoTracking().AsQueryable();
        var term = Search?.Trim();
        if (!string.IsNullOrEmpty(term))
            q = q.Where(p => p.Name.Contains(term) || p.Code.Contains(term));
        Products = await q.OrderBy(p => p.Code).ToListAsync();
    }

    public async Task<IActionResult> OnPostDeleteAsync(int id)
    {
        var p = await _db.Products.FindAsync(id);
        if (p != null)
        {
            _db.Products.Remove(p);
            await _db.SaveChangesAsync();
            TempData["Message"] = $"\"{p.Name}\" deleted.";
        }
        return RedirectToPage(new { search = Search });
    }
}
