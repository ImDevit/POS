using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Data;
using PoSophornCafe.Models;
using PoSophornCafe.Services;

namespace PoSophornCafe.Pages;

public class IndexModel : PageModel
{
    private readonly AppDbContext _db;
    private readonly ShopClock _clock;

    public IndexModel(AppDbContext db, ShopClock clock)
    {
        _db = db;
        _clock = clock;
    }

    public DateTime CurrentDate => _clock.Now;
    public decimal TodaySales { get; set; }
    public int OrdersToday { get; set; }
    public int ProductCount { get; set; }
    public int LowStock { get; set; }
    public List<Order> Recent { get; set; } = new();

    public async Task OnGetAsync()
    {
        var start = _clock.Today;
        var end = start.AddDays(1);
        var today = _db.Orders.Where(o => o.OrderDate >= start && o.OrderDate < end);

        OrdersToday = await today.CountAsync();
        TodaySales = await today.SumAsync(o => (decimal?)o.Total) ?? 0m;
        ProductCount = await _db.Products.CountAsync();
        LowStock = await _db.Products.CountAsync(p => p.Qty <= 5);
        Recent = await _db.Orders.Include(o => o.Items)
            .OrderByDescending(o => o.OrderDate).Take(5).ToListAsync();
    }
}
