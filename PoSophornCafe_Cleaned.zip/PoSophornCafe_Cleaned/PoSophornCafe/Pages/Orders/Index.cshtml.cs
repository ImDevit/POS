using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Data;
using PoSophornCafe.Models;
using PoSophornCafe.Services;

namespace PoSophornCafe.Pages.Orders;

public class PayLine
{
    public int ProductId { get; set; }
    public int Qty { get; set; }
}

public class PayRequest
{
    public string? OrderType { get; set; }
    public List<PayLine?>? Items { get; set; }
}

public class IndexModel : PageModel
{
    private readonly AppDbContext _db;
    private readonly ShopClock _clock;
    public IndexModel(AppDbContext db, ShopClock clock) { _db = db; _clock = clock; }

    public List<Product> Products { get; set; } = new();
    public List<Order> Recent { get; set; } = new();

    public async Task OnGetAsync()
    {
        Products = await _db.Products.AsNoTracking().OrderBy(p => p.Name).ToListAsync();
        Recent = await _db.Orders.Include(o => o.Items).AsNoTracking()
            .OrderByDescending(o => o.OrderDate).Take(10).ToListAsync();
    }

    // Called by JavaScript when the cashier presses "Payment".
    // Prices and stock are always taken from the database, never trusted from the browser.
    public async Task<IActionResult> OnPostPayAsync([FromBody] PayRequest req)
    {
        if (req is null || req.Items is null || req.Items.Count == 0)
        {
            return BadRequest(new
            {
                error = "Please add at least one product first."
            });
        }

        var items = req.Items;

        // Keep requests bounded and reject malformed lines before querying the database.
        if (items.Count > 100 ||
            items.Any(item => item is null ||
                              item.ProductId <= 0 ||
                              item.Qty <= 0 ||
                              item.Qty > 1000))
        {
            return BadRequest(new { error = "Invalid order items." });
        }

        var lines = items
            .Select(item => item!)
            .GroupBy(item => item.ProductId)
            .Select(group => new
            {
                ProductId = group.Key,
                Qty = group.Sum(item => (long)item.Qty)
            })
            .ToList();

        if (lines.Any(line => line.Qty > 1000))
            return BadRequest(new { error = "Maximum quantity per product is 1,000." });

        var ids = lines.Select(l => l.ProductId).ToList();
        var products = await _db.Products.Where(p => ids.Contains(p.Id)).ToDictionaryAsync(p => p.Id);

        foreach (var l in lines)
        {
            if (!products.TryGetValue(l.ProductId, out var p))
                return BadRequest(new { error = "A product in this order no longer exists." });
            if (p.Qty < l.Qty)
                return BadRequest(new { error = $"Not enough stock for {p.Name}." });
        }

        await using var tx = await _db.Database.BeginTransactionAsync();
        try
        {
            var now = _clock.Now;
            var queue = await _db.Orders.CountAsync(o => o.OrderDate >= now.Date) + 1;
            var order = new Order
            {
                Number = Guid.NewGuid().ToString("N"),   // temporary, replaced below once the Id is known
                Queue = queue,
                OrderType = req.OrderType == "Dine In" ? "Dine In" : "Take Away",
                OrderDate = now
            };
            foreach (var l in lines)
            {   
                var p = products[l.ProductId];
                p.Qty -= (int)l.Qty;
                order.Items.Add(new OrderItem { ProductId = p.Id, Name = p.Name, Price = p.Price, Qty = (int)l.Qty });
            }
            order.Total = order.Items.Sum(i => i.Price * i.Qty);

            _db.Orders.Add(order);
            await _db.SaveChangesAsync();
            order.Number = $"POS1-{order.Id:D5}";
            await _db.SaveChangesAsync();
            await tx.CommitAsync();

            return new JsonResult(new
            {
                order = OrderDto.From(order),
                stock = products.Values.Select(p => new { id = p.Id, qty = p.Qty }).ToList()
            });
        }
        catch (DbUpdateConcurrencyException)
        {
            return new ObjectResult(new
            {
                error = "Stock was just changed by someone else. Please try again."
            })
            {
                StatusCode = StatusCodes.Status409Conflict
            };
        }
    }
}
