using System.Text.Json;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Data;
using PoSophornCafe.Models;
using PoSophornCafe.Services;

namespace PoSophornCafe.Pages.Reports;

public class IndexModel : PageModel
{
    private readonly AppDbContext _db;
    private readonly ShopClock _clock;
    public IndexModel(AppDbContext db, ShopClock clock) { _db = db; _clock = clock; }

    // Filters (all come from the query string, so a report URL can be bookmarked or shared)
    [BindProperty(SupportsGet = true)] public string Period { get; set; } = "day";
    [BindProperty(SupportsGet = true)] public DateTime? Date { get; set; }
    [BindProperty(SupportsGet = true)] public DateTime? From { get; set; }
    [BindProperty(SupportsGet = true)] public DateTime? To { get; set; }

    public List<Order> Orders { get; set; } = new();
    public decimal TotalSales { get; set; }
    public int ItemsSold { get; set; }
    public decimal Average => Orders.Count == 0 ? 0 : TotalSales / Orders.Count;
    public string PeriodLabel { get; set; } = "";
    public string PrintJson { get; set; } = "{}";
    public DateTime DateValue => (Date ?? _clock.Today).Date;

    private static readonly string[] Allowed = { "day", "range", "today", "week", "month", "all" };

    private async Task LoadAsync()
    {
        if (!Allowed.Contains(Period)) Period = "day";
        var today = _clock.Today;
        var q = _db.Orders.Include(o => o.Items).AsNoTracking().AsQueryable();

        switch (Period)
        {
            case "day":
            {
                var d = DateValue; var next = d.AddDays(1);
                q = q.Where(o => o.OrderDate >= d && o.OrderDate < next);
                PeriodLabel = d.ToString("yyyy-MM-dd");
                break;
            }
            case "range":
            {
                if (From.HasValue) { var f = From.Value.Date; q = q.Where(o => o.OrderDate >= f); }
                if (To.HasValue) { var t = To.Value.Date.AddDays(1); q = q.Where(o => o.OrderDate < t); }
                PeriodLabel = $"{From:yyyy-MM-dd} to {To:yyyy-MM-dd}";
                break;
            }
            case "today":
            {
                var next = today.AddDays(1);
                q = q.Where(o => o.OrderDate >= today && o.OrderDate < next);
                PeriodLabel = today.ToString("yyyy-MM-dd");
                break;
            }
            case "week":
            {
                var w = today.AddDays(-6);
                q = q.Where(o => o.OrderDate >= w);
                PeriodLabel = $"{w:yyyy-MM-dd} to {today:yyyy-MM-dd}";
                break;
            }
            case "month":
            {
                var m = new DateTime(today.Year, today.Month, 1);
                q = q.Where(o => o.OrderDate >= m);
                PeriodLabel = today.ToString("MMMM yyyy");
                break;
            }
            default:
                PeriodLabel = "All time";
                break;
        }

        Orders = await q.OrderByDescending(o => o.OrderDate).ToListAsync();
        TotalSales = Orders.Sum(o => o.Total);
        ItemsSold = Orders.Sum(o => o.Items.Sum(i => i.Qty));
    }

    private List<OrderItemDto> Lines() => Orders.SelectMany(o => o.Items)
        .GroupBy(i => new { i.Name, i.Price })
        .Select(g => new OrderItemDto(g.Key.Name, g.Key.Price, g.Sum(x => x.Qty)))
        .OrderBy(l => l.Name).ToList();

    private string TypeLabel() => Period switch
    {
        "day" or "today" => "Daily Report",
        "range" => "Date Range Report",
        "week" => "Weekly Report",
        "month" => "Monthly Report",
        _ => "All-time Report"
    };

    public async Task OnGetAsync()
    {
        await LoadAsync();
        // Data for the "Print report" receipt (JSON encoder escapes < > & so it is safe inside <script>).
        PrintJson = JsonSerializer.Serialize(new
        {
            typeLabel = TypeLabel(),
            periodLabel = PeriodLabel,
            orderCount = Orders.Count,
            lines = Lines(),
            totalQty = ItemsSold,
            total = TotalSales
        }, new JsonSerializerOptions(JsonSerializerDefaults.Web));
    }

    public async Task<IActionResult> OnGetExportAsync()
    {
        await LoadAsync();
        using var wb = new XLWorkbook();

        // Sheet 1: summary (same table as the printed receipt)
        var s = wb.AddWorksheet("Summary");
        s.Cell(1, 1).Value = "Po Sophorn Cafe - Sales Report"; s.Cell(1, 1).Style.Font.Bold = true; s.Cell(1, 1).Style.Font.FontSize = 14;
        s.Cell(2, 1).Value = "Period"; s.Cell(2, 2).Value = PeriodLabel;
        s.Cell(3, 1).Value = "Exported"; s.Cell(3, 2).Value = _clock.Now.ToString("dd/MM/yyyy hh:mm tt");
        var header = new[] { "Description", "Qty", "Price", "Disc", "Amount" };
        for (int c = 0; c < header.Length; c++) { var h = s.Cell(5, c + 1); h.Value = header[c]; h.Style.Font.Bold = true; h.Style.Fill.BackgroundColor = XLColor.FromHtml("#E4EFDF"); }
        int r = 6;
        foreach (var l in Lines())
        {
            s.Cell(r, 1).Value = l.Name; s.Cell(r, 2).Value = l.Qty; s.Cell(r, 3).Value = l.Price; s.Cell(r, 4).Value = "0%"; s.Cell(r, 5).Value = l.Price * l.Qty;
            r++;
        }
        r++;
        s.Cell(r, 1).Value = "Total QTY"; s.Cell(r, 2).Value = ItemsSold; r++;
        s.Cell(r, 1).Value = "Sub Total ($)"; s.Cell(r, 5).Value = TotalSales; r++;
        s.Cell(r, 1).Value = "Discount"; s.Cell(r, 5).Value = 0m; r++;
        s.Cell(r, 1).Value = "Receive / CASH USD"; s.Cell(r, 5).Value = TotalSales; s.Range(r, 1, r, 5).Style.Font.Bold = true;
        s.Range(6, 3, r, 3).Style.NumberFormat.Format = "$#,##0.00";
        s.Range(6, 5, r, 5).Style.NumberFormat.Format = "$#,##0.00";
        s.Columns().AdjustToContents();

        // Sheet 2: one row per invoice
        var d = wb.AddWorksheet("Orders");
        var dh = new[] { "Invoice", "Order Type", "Date & Time", "Products", "Qty", "Total ($)" };
        for (int c = 0; c < dh.Length; c++) { var h = d.Cell(1, c + 1); h.Value = dh[c]; h.Style.Font.Bold = true; h.Style.Fill.BackgroundColor = XLColor.FromHtml("#E4EFDF"); }
        int row = 2;
        foreach (var o in Orders)
        {
            d.Cell(row, 1).Value = o.Number; d.Cell(row, 2).Value = o.OrderType;
            d.Cell(row, 3).Value = o.OrderDate.ToString("dd/MM/yyyy hh:mm tt");
            d.Cell(row, 4).Value = string.Join(", ", o.Items.Select(i => $"{i.Name} x {i.Qty}"));
            d.Cell(row, 5).Value = o.Items.Sum(i => i.Qty); d.Cell(row, 6).Value = o.Total;
            row++;
        }
        d.Range(2, 6, Math.Max(row - 1, 2), 6).Style.NumberFormat.Format = "$#,##0.00";
        d.Columns().AdjustToContents();

        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return File(ms.ToArray(),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            $"Sales-Report-{_clock.Today:yyyy-MM-dd}.xlsx");
    }
}
