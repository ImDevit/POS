using PoSophornCafe.Models;

namespace PoSophornCafe.Data;

public static class SeedData
{
    public static void Initialize(AppDbContext db)
    {
        if (db.Products.Any()) return;
        db.Products.AddRange(
            new Product { Code = "P0001232", Name = "Iced Latte",     Qty = 20, Price = 1.00m, Emoji = "🥤" },
            new Product { Code = "P0001233", Name = "Black Coffee",   Qty = 30, Price = 1.00m, Emoji = "☕" },
            new Product { Code = "P0001234", Name = "Iced Lemon Tea", Qty = 18, Price = 1.00m, Emoji = "🧋" },
            new Product { Code = "P0001235", Name = "Matcha Lime",    Qty = 12, Price = 1.25m, Emoji = "🍵" },
            new Product { Code = "P0001236", Name = "Soda",           Qty = 15, Price = 1.00m, Emoji = "🥫" },
            new Product { Code = "P0001237", Name = "Energy Drink",   Qty = 10, Price = 1.00m, Emoji = "🥤" });
        db.SaveChanges();
    }
}
