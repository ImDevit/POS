using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Models;

namespace PoSophornCafe.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Product> Products => Set<Product>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Product>(e =>
        {
            e.HasIndex(p => p.Code).IsUnique();
            e.Property(p => p.Price).HasPrecision(10, 2);
        });

        b.Entity<Order>(e =>
        {
            e.HasIndex(o => o.Number).IsUnique();
            e.HasIndex(o => o.OrderDate);
            e.Property(o => o.Number).HasMaxLength(40);
            e.Property(o => o.OrderType).HasMaxLength(20);
            e.Property(o => o.Total).HasPrecision(10, 2);
        });

        b.Entity<OrderItem>(e =>
        {
            e.Property(i => i.Name).HasMaxLength(100);
            e.Property(i => i.Price).HasPrecision(10, 2);
            e.HasOne(i => i.Order).WithMany(o => o.Items).HasForeignKey(i => i.OrderId).OnDelete(DeleteBehavior.Cascade);
            // Deleting a product keeps the old invoices.
            e.HasOne(i => i.Product).WithMany().HasForeignKey(i => i.ProductId).OnDelete(DeleteBehavior.SetNull);
        });
    }
}
