# Po Sophorn Cafe — ASP.NET Core Razor Pages + SQL Server

Your front-end, now connected to a real database.

## What you need
1. **.NET 8 SDK** – https://dotnet.microsoft.com/download
2. **SQL Server** – either
   - *LocalDB* (comes with Visual Studio; default in `appsettings.json`), or
   - SQL Server / SQL Server Express (replace `DefaultConnection` in `appsettings.json` with a connection string such as `Server=localhost;Database=PoSophornCafe;User Id=sa;Password=YOUR_PASSWORD;TrustServerCertificate=True`).

## Run
```
cd PoSophornCafe
dotnet run
```
Open the https address shown in the terminal (or press F5 in Visual Studio / VS Code).

On the first start the app **creates the database `PoSophornCafe`, all tables and 6 sample drinks automatically**
(`Program.cs` → `EnsureCreated()` + `Data/SeedData.cs`).

## Database tables
| Table | Columns |
|---|---|
| `Products` | Id, Code (unique), Name, Qty, Price, Emoji, RowVersion |
| `Orders` | Id, Number (POS1-00001, unique), Queue (daily waiting no.), OrderType, OrderDate, Total |
| `OrderItems` | Id, OrderId → Orders, ProductId → Products (NULL if product deleted), Name, Price, Qty |

Order items store a copy of the name and price, so old invoices never change when you edit or delete a product.

## Folder map
```
Program.cs              start-up, database setup, /api/orders/{number} (used to print an invoice again)
Data/                   AppDbContext (tables) + SeedData (sample drinks)
Models/                 Product, Order, OrderItem, OrderDto
Services/ShopClock.cs   shop time zone ("ShopTimeZone" in appsettings.json)
Pages/Index             Dashboard
Pages/Products/         Index (list, search, delete) + Edit (add / edit)
Pages/Orders/           POS screen; handler OnPostPayAsync saves the order and reduces stock
Pages/Reports/          Calendar filter, print report, handler OnGetExportAsync → Excel (.xlsx)
wwwroot/                css, js/app.js (cart + receipt printing), img/logo.png
```

## How the important rules work
- **Payment** (`Pages/Orders/Index.cshtml.cs`): the browser only sends product ids + quantities. The server reads real
  prices and stock from SQL Server, checks stock, reduces stock and saves the order in one transaction.
- **Print again**: "Print again" buttons (Orders and Report pages) call `GET /api/orders/{number}` and print that invoice.
  It never creates an order and never changes stock.
- **Excel**: Report → *Export Excel* builds the file on the server with ClosedXML, using the same filter as the page
  (Summary sheet + Orders sheet).
- **Two cashiers, last cup**: `Products.RowVersion` makes the second payment fail with "Stock was just changed" instead of selling stock twice.

## Before real use (not included yet)
- **Login** – done (see "First page, Sign in and Create account" below). Roles (owner / cashier) are still not included.
- **Migrations** – `EnsureCreated()` is great to start, but it cannot change an existing database. When you want to add columns later,
  remove `EnsureCreated()` and use `dotnet tool install --global dotnet-ef`, `dotnet ef migrations add Init`, `dotnet ef database update`.
- Back up the SQL Server database regularly.


## Keep the project clean

Generated folders such as `.vs/`, `bin/`, and `obj/` are excluded from the source ZIP
and should not be committed to source control. They are recreated by Visual Studio or
the .NET SDK when the project is opened or built. The `.gitignore` file lists these
generated files and folders.


## First page, Sign in and Create account (new)

When the app starts, the **first page** opens. Everything else needs a login.

```
Open site  ->  First page (/Welcome)  ->  Sign in  or  Create account  ->  Dashboard
                                            Log out (sidebar)  ->  back to First page
```

| Page | URL | Files |
|---|---|---|
| First page | `/Welcome` | `Pages/Welcome.cshtml` (+ `.cs`), `wwwroot/css/landing.css`, `wwwroot/js/landing.js` |
| Sign in | `/Account/Login` | `Pages/Account/Login.cshtml` (+ `.cs`) |
| Create account | `/Account/Register` | `Pages/Account/Register.cshtml` (+ `.cs`) |
| Log out | `/Account/Logout` (POST) | `Pages/Account/Logout.cshtml` (+ `.cs`) |
| Styles / images | – | `wwwroot/css/auth.css`, `wwwroot/img/logo-cream.png` |
| Users | table `Users` | `Models/AppUser.cs`, `Services/SignInHelper.cs` |

### How it works
- **Create account** saves the user in the new `Users` table (password stored only as a salted hash, using the
  built-in ASP.NET Core `PasswordHasher`), signs the user in and opens the Dashboard.
  Username and email must be unique.
- **Sign in** accepts the username *or* the email. A wrong username/password shows a red message.
- **Protection:** `Program.cs` now requires a login for every page and for `/api/orders/...`. Only `/Welcome`,
  `/Account/*` and `/Error` are public. If a signed-out person opens any other address they are sent to the first page.
  After signing in, the browser opens the Dashboard.
- **Session:** the login cookie lasts until the browser is closed (and at most 8 hours of inactivity).
- **Users table:** created automatically on start (new database, or existing database - same way as the
  `ImagePath` / `Emoji` columns). No `dotnet ef` command is needed. Do not run `dotnet ef migrations` on this project
  while `EnsureCreated()` is used - mixing the two causes "table already exists" errors.

### Existing files I had to change (small edits)
| File | Change |
|---|---|
| `Program.cs` | login cookie + "must be signed in" rule, `Users` table creation, `UseAuthentication()` |
| `Data/AppDbContext.cs` | one line: `DbSet<AppUser> Users` |
| `Pages/Shared/_Layout.cshtml` | Log out button now really logs out; top bar shows the signed-in user's name and initial instead of "Devit" |
| `wwwroot/js/app.js` | removed the one line that showed "Login is not set up yet" |
| `README.md` | this section |

### Things to know / still to decide
- **Anyone can create an account and then use the system.** That is how the pages were requested, but for a real shop
  you may want only the owner to create accounts (hide Create account, or add an approval step / roles).
- No "forgot password", no lock-out after many wrong passwords.
- **Name and colours:** the shop name is "Po Sophorn Cafe" everywhere, and the first page uses the app's green + cream
  colours (`wwwroot/css/landing.css`, the colour variables at the top). The Contact e-mail on the first page is a
  placeholder, `hello@posophorncafe.com` - replace it in `Pages/Welcome.cshtml` with your real address.
- **Background photo:** save your coffee photo as `wwwroot/img/auth-bg.jpg` to show it behind the green panel.
- Fonts (Inter, Cormorant Garamond, DM Sans) load from Google Fonts and need internet.
- I could not run `dotnet build` where I made these changes - press F5 once and tell me if there is any error.
