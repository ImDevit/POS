using System.Globalization;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Data;
using PoSophornCafe.Models;
using PoSophornCafe.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages(options =>
{
    // Pages anyone can open without signing in. Every other page needs a login (see fallback policy below).
    options.Conventions.AllowAnonymousToPage("/Welcome");
    options.Conventions.AllowAnonymousToPage("/Error");
    options.Conventions.AllowAnonymousToFolder("/Account");
});

// Login: a cookie is created after Sign in / Create account. Not signed in -> the first page (/Welcome).
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Welcome";
        options.AccessDeniedPath = "/Welcome";
        options.Cookie.Name = "PoSophornCafe.Auth";
        options.Cookie.HttpOnly = true;
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.SlidingExpiration = true;
    });
builder.Services.AddAuthorization(options =>
{
    // Everything (pages + /api/orders) requires a signed-in user unless marked anonymous above.
    options.FallbackPolicy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
});
builder.Services.AddSingleton<IPasswordHasher<AppUser>, PasswordHasher<AppUser>>();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddSingleton<ShopClock>();
// JavaScript (fetch) sends the anti-forgery token in this header.
builder.Services.AddAntiforgery(options => options.HeaderName = "RequestVerificationToken");

var app = builder.Build();

// Create the database + tables on first run, then add the sample drinks.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();

    // EnsureCreated() never changes an existing database. If the DB was created before a column
    // was added to Product, add the missing columns here (safe to run every start).
    db.Database.ExecuteSqlRaw(@"
IF COL_LENGTH('Products', 'ImagePath') IS NULL
    ALTER TABLE Products ADD ImagePath nvarchar(500) NULL;
IF COL_LENGTH('Products', 'Emoji') IS NULL
    ALTER TABLE Products ADD Emoji nvarchar(10) NULL;");

    // Same idea for the new Users table (sign in / create account) on a database made before it existed.
    db.Database.ExecuteSqlRaw(@"
IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users (
        Id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
        FullName nvarchar(100) NOT NULL,
        Username nvarchar(50) NOT NULL,
        Company nvarchar(100) NULL,
        Phone nvarchar(20) NOT NULL,
        Email nvarchar(150) NOT NULL,
        PasswordHash nvarchar(max) NOT NULL,
        CreatedAt datetime2 NOT NULL
    );
    CREATE UNIQUE INDEX IX_Users_Username ON dbo.Users (Username);
    CREATE UNIQUE INDEX IX_Users_Email ON dbo.Users (Email);
END");

    SeedData.Initialize(db);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

// One culture everywhere so "1.50" is always written with a dot (needed by <input type="number">).
var culture = new CultureInfo("en-US");
app.UseRequestLocalization(new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture(culture),
    SupportedCultures = new[] { culture },
    SupportedUICultures = new[] { culture }
});

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

// Used to print an invoice again (Orders + Report pages). Read-only: it never creates an order.
app.MapGet("/api/orders/{number}", async (string number, AppDbContext db) =>
{
    var order = await db.Orders.Include(o => o.Items).AsNoTracking()
        .FirstOrDefaultAsync(o => o.Number == number);
    return order is null ? Results.NotFound(new { error = "Order not found." }) : Results.Ok(OrderDto.From(order));
});

app.MapRazorPages();
app.Run();