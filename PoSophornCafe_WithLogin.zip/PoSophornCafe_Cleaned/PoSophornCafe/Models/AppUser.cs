using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace PoSophornCafe.Models;

// A person who can sign in to the system. Passwords are stored only as a salted hash.
[Index(nameof(Username), IsUnique = true)]
[Index(nameof(Email), IsUnique = true)]
public class AppUser
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    public string FullName { get; set; } = "";

    [Required, StringLength(50)]
    public string Username { get; set; } = "";

    [StringLength(100)]
    public string? Company { get; set; }

    [Required, StringLength(20)]
    public string Phone { get; set; } = "";

    [Required, StringLength(150)]
    public string Email { get; set; } = "";

    [Required]
    public string PasswordHash { get; set; } = "";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
