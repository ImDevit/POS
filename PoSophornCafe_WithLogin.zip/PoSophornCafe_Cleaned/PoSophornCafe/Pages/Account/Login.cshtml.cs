using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Data;
using PoSophornCafe.Models;
using PoSophornCafe.Services;

namespace PoSophornCafe.Pages.Account;

public class LoginModel : PageModel
{
    private readonly AppDbContext _db;
    private readonly IPasswordHasher<AppUser> _hasher;

    public LoginModel(AppDbContext db, IPasswordHasher<AppUser> hasher)
    {
        _db = db;
        _hasher = hasher;
    }

    [BindProperty]
    public LoginInput Input { get; set; } = new();

    // Page the visitor wanted before being sent to sign in (only local addresses are used).
    [BindProperty(SupportsGet = true)]
    public string? ReturnUrl { get; set; }

    public IActionResult OnGet()
    {
        if (User.Identity?.IsAuthenticated == true)
            return RedirectToPage("/Index");
        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
            return Page();

        // The username box also accepts the email address.
        var name = Input.Username.Trim();
        var user = await _db.Users.FirstOrDefaultAsync(u => u.Username == name || u.Email == name);

        if (user == null ||
            _hasher.VerifyHashedPassword(user, user.PasswordHash, Input.Password) == PasswordVerificationResult.Failed)
        {
            ModelState.AddModelError(string.Empty, "Invalid username or password.");
            return Page();
        }

        await SignInHelper.SignInAsync(HttpContext, user);
        return LocalRedirect(Url.IsLocalUrl(ReturnUrl) ? ReturnUrl! : "/");
    }

    public class LoginInput
    {
        [Required(ErrorMessage = "Please enter your username.")]
        [StringLength(150)]
        public string Username { get; set; } = "";

        [Required(ErrorMessage = "Please enter your password.")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = "";
    }
}
