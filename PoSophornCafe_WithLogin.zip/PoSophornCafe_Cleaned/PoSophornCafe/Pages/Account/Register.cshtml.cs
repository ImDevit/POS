using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using PoSophornCafe.Data;
using PoSophornCafe.Models;
using PoSophornCafe.Services;

namespace PoSophornCafe.Pages.Account;

public class RegisterModel : PageModel
{
    private readonly AppDbContext _db;
    private readonly IPasswordHasher<AppUser> _hasher;

    public RegisterModel(AppDbContext db, IPasswordHasher<AppUser> hasher)
    {
        _db = db;
        _hasher = hasher;
    }

    [BindProperty]
    public RegisterInput Input { get; set; } = new();

    public IActionResult OnGet()
    {
        if (User.Identity?.IsAuthenticated == true)
            return RedirectToPage("/Index");
        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        var username = (Input.Username ?? "").Trim();
        var email = (Input.Email ?? "").Trim();

        if (ModelState.IsValid)
        {
            if (await _db.Users.AnyAsync(u => u.Username == username))
                ModelState.AddModelError("Input.Username", "This username is already taken.");
            if (await _db.Users.AnyAsync(u => u.Email == email))
                ModelState.AddModelError("Input.Email", "An account with this email already exists.");
        }

        if (!ModelState.IsValid)
            return Page();

        var user = new AppUser
        {
            FullName = Input.FullName.Trim(),
            Username = username,
            Company = string.IsNullOrWhiteSpace(Input.Company) ? null : Input.Company.Trim(),
            Phone = Input.Phone.Trim(),
            Email = email,
            CreatedAt = DateTime.UtcNow
        };
        user.PasswordHash = _hasher.HashPassword(user, Input.Password);

        try
        {
            _db.Users.Add(user);
            await _db.SaveChangesAsync();
        }
        catch (DbUpdateException)
        {
            // Someone took the same username/email a moment ago (unique index).
            ModelState.AddModelError(string.Empty, "That username or email is already registered.");
            return Page();
        }

        // Account created -> sign in straight away and open the dashboard.
        await SignInHelper.SignInAsync(HttpContext, user);
        return RedirectToPage("/Index");
    }

    public class RegisterInput
    {
        [Required(ErrorMessage = "Please enter your full name.")]
        [StringLength(100)]
        public string FullName { get; set; } = "";

        [Required(ErrorMessage = "Please choose a username.")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Username must be 3-50 characters.")]
        [RegularExpression(@"^[A-Za-z0-9._-]+$", ErrorMessage = "Use letters, numbers, dot, dash or underscore only.")]
        public string Username { get; set; } = "";

        [StringLength(100)]
        public string? Company { get; set; }

        [Required(ErrorMessage = "Please enter your phone number.")]
        [RegularExpression(@"^\+?[0-9 ()-]{6,20}$", ErrorMessage = "Enter a valid phone number.")]
        public string Phone { get; set; } = "";

        [Required(ErrorMessage = "Please enter your email address.")]
        [EmailAddress(ErrorMessage = "Enter a valid email address.")]
        [StringLength(150)]
        public string Email { get; set; } = "";

        [Required(ErrorMessage = "Please create a password.")]
        [RegularExpression(@"^(?=.*\d).{8,}$", ErrorMessage = "Use at least 8 characters, including a number.")]
        [DataType(DataType.Password)]
        public string Password { get; set; } = "";

        [Required(ErrorMessage = "Please re-enter your password.")]
        [Compare(nameof(Password), ErrorMessage = "Passwords do not match.")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; } = "";

        [Range(typeof(bool), "true", "true", ErrorMessage = "You must agree to the Terms of Service and Privacy Policy.")]
        public bool AgreeTerms { get; set; }
    }
}
