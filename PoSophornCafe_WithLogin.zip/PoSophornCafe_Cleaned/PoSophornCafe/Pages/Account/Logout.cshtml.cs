using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PoSophornCafe.Pages.Account;

public class LogoutModel : PageModel
{
    // Typing /Account/Logout in the browser does nothing harmful: just go to the first page.
    public IActionResult OnGet() => RedirectToPage("/Welcome");

    public async Task<IActionResult> OnPostAsync()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToPage("/Welcome");
    }
}
